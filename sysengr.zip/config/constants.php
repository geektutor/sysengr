<?php

	$hod_mail = 'test@test.com';
	$superviser_mail = 'mumu@mumu.com';
	$course_adviser_mail = 'zubairidrisaweda@gmail.com';

	$lecturers = [
		'Mr. Dele' => 'dele1@gmail.com',
		'Prof. Yomi' => 'yomishow@gmail.com',
		'Dr. Geek' => 'daddysodiq@gmail.com'
	];

?>